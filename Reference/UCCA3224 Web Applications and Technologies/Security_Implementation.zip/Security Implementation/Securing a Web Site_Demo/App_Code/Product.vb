﻿Imports Microsoft.VisualBasic

Public Class Product
    Public Property ProductID As String
    Public Property Name As String
    Public Property ShortDescription As String
    Public Property LongDescription As String
    Public Property UnitPrice As Decimal
    Public Property ImageFile As String
End Class
