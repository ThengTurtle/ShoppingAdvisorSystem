﻿
Partial Class MyDefault
    Inherits System.Web.UI.Page

End Class
