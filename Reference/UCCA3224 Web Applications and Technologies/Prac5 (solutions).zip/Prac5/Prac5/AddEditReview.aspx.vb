﻿Public Class AddEditReview
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Label4.Text = DateTime.Now.ToString("d/M/yyyy h:mm:ss")

    End Sub

    Private Sub SqlDataSource1_Updated(sender As Object, e As SqlDataSourceStatusEventArgs) Handles SqlDataSource1.Updated
        If e.AffectedRows = 0 Then
            lblMessage.Text = "No update was performed. A concurrency error is likely, or the command is incorrectly written"
        Else
            lblMessage.Text = "Record successfully updated."

        End If
    End Sub



    Private Sub DetailsView1_ItemUpdating(sender As Object, e As DetailsViewUpdateEventArgs) Handles DetailsView1.ItemUpdating

        Dim o_udt = CType(CType(DetailsView1.FindControl("TextBox2"), TextBox).Text, DateTime)
      
        SqlDataSource1.UpdateParameters("original_Id").DefaultValue = DetailsView1.DataKey.Value
        SqlDataSource1.UpdateParameters("UpdateDateTime").DefaultValue = DateTime.Now
        SqlDataSource1.UpdateParameters("original_UpdateDateTime").DefaultValue = o_udt


    End Sub
End Class