﻿Public Class Reviews
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Function GetBooleanText(booleanValue As Object) As String
        Dim authorized As Boolean = CType(booleanValue, Boolean)

        If authorized Then
            Return "Yes"
        Else
            Return "No"
        End If
    End Function

End Class