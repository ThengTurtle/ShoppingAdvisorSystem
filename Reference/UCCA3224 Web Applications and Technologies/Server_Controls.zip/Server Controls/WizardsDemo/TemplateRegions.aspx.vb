﻿
Partial Class TemplateRegions
    Inherits System.Web.UI.Page

End Class
