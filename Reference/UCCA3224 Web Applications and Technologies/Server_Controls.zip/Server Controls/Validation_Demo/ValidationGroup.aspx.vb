﻿
Partial Class ValidationGroup
    Inherits System.Web.UI.Page


End Class
