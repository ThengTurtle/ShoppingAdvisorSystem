﻿
Partial Class GridViewTemplateEdit
    Inherits System.Web.UI.Page

End Class
