
Partial Class GridViewPaging
    Inherits System.Web.UI.Page

End Class
