
Partial Class SqlDataSourceSimple
    Inherits System.Web.UI.Page

End Class
