﻿
Partial Class SqlDataSourceDelete
    Inherits System.Web.UI.Page

End Class
