﻿
Partial Class SqlDataSourceInsert
    Inherits System.Web.UI.Page

End Class
